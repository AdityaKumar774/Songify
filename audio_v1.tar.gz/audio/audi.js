$('body').on('click', function(){
var song = document.querySelector('audio');
 if(song.paused == true){
  console.log('Playing');
  song.play();
 }
 else{
  console.log('Paused')
  song.pause();
 }
});