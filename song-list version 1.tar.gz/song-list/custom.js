var songName = ['song1.mp3', 'song2.mp3', 'song3.mp3', 'song4.mp3']
window.onload = function(){
	$('.first-song').text(songName[0]);
	$('.second-song').text(songName[1]);
	$('.third-song').text(songName[2]);
	$('.fourth-song').text(songName[3]);
}

$('.first-song').on('click', function(){
	$('#play-selected').attr('src', "song1.mp3");
});

$('.second-song').on('click', function(){
	$('#play-selected').attr('src', "song2.mp3");
});

$('.third-song').on('click', function(){
	$('#play-selected').attr('src', "song3.mp3");
});

$('.fourth-song').on('click', function(){
	$('#play-selected').attr('src', "song4.mp3");
});