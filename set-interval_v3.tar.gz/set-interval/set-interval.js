$('.play-pause').on('click',function() {
				var song = document.querySelector('audio');
				if(song.paused == true) {
					console.log('Playing');
								$('.fa-play').removeClass('fa-play').addClass('fa-pause');
								song.play();
				}
				else {
					console.log('Pausing');
							$('.fa-pause').removeClass('fa-pause').addClass('fa-play');
							song.pause();
			}
}); 

$('body').on('keypress',function(event) {
								if (event.keyCode == 32)
								{
											var song = document.querySelector('audio');
											if(song.paused == true) {
											console.log('Playing');
													$('.fa-play').removeClass('fa-play').addClass('fa-pause');
													song.play();
								}
								else {
								console.log('Pausing');
											$('.fa-pause').removeClass('fa-pause').addClass('fa-play');
											song.pause();
							}
				}
}); 

function fancyTimeFormat(time)
{   
    // Hours, minutes and seconds
    var hrs = ~~(time / 3600);
    var mins = ~~((time % 3600) / 60);
    var secs = time % 60;

    // Output like "1:01" or "4:03:59" or "123:03:59"
    var ret = "";

    if (hrs > 0) {
        ret += "" + hrs + ":" + (mins < 10 ? "0" : "");
    }

    ret += "" + mins + ":" + (secs < 10 ? "0" : "");
    ret += "" + secs;
    return ret;
}

function updateCurrentTime(){
    arr = $('.audio-song');
    time1 = arr[0].duration;
    time1 = fancyTimeFormat(time1);
    time2 = arr[0].currentTime;
    time2 = fancyTimeFormat(time2);
    $('.total-duration').text("Total duration : " + time1 + " seconds");
    $('.current-time').text("Current duration : " + time2 + " seconds");
}

window.onload = function(){
    updateCurrentTime();
}

$('.play-pause').on('click',function(){
    setInterval(function(){
        updateCurrentTime(); 
    }, 1000);
});