$('button').on('click',function() {
var song = document.querySelector('audio');
if(song.paused == true) {
 console.log('Playing');
$('.fa-play').removeClass('fa-play').addClass('fa-pause');
song.play();
}
else {
 console.log('Pausing');
$('.fa-pause').removeClass('fa-pause').addClass('fa-play');
song.pause();
}
}); 

$('body').on('keypress',function(event) {
if (event.keyCode == 32)
{
var song = document.querySelector('audio');
if(song.paused == true) {
console.log('Playing');
$('.fa-play').removeClass('fa-play').addClass('fa-pause');
song.play();
}
else {
console.log('Pausing');
$('.fa-pause').removeClass('fa-pause').addClass('fa-play');
song.pause();
}
}
}); 