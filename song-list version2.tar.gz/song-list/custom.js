var songName = ['song1', 'song2', 'song3', 'song4']
var fileNames = ['song1.mp3', 'song2.mp3', 'song3.mp3', 'song4.mp3']

window.onload = function(){
	$('#song1').text(songName[0]);
	$('#song2').text(songName[1]);
	$('#song3').text(songName[2]);
	$('#song4').text(songName[3]);
}

function toggleSong(){
	var song = document.querySelector('audio');
	if(song.paused){
		song.play();
	}else{
		song.pause();
	}
}


function addSongEventListener(songName, position){
	var id = '#song' + position;
	
	$(id).on('click', function(event){
		var song = document.querySelector('audio');
		var currentSong = song.src;
		
		if(currentSong.search(songName) != -1){
			toggleSong();
		}else{ 
          song.src = songName;
			song.play();
		}
		
	});
}

for(var i = 0; i < fileNames.length; i++){
	addSongEventListener(fileNames[i], i + 1);
}